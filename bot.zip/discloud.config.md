NAME=BotTreoRoom  
TYPE=bot  
MAIN=main.py  
RAM=100  
AUTORESTART=true  
VERSION=latest  
APT=tools  
